<<<<<<< HEAD
#chess_error.py  05Mar2025  crs, Author

class ChessError(Exception):
    def __init__(self, msg):
        raise Exception(msg)
=======
#chess_error.py  05Mar2025  crs, Author

class ChessError(Exception):
    def __init__(self, msg):
        raise Exception(msg)
>>>>>>> 17b7b90322a44a0fded3840c272b470acdb75dba
    