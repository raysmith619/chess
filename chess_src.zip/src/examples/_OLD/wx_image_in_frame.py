#wx_image_in_frame.py
import wx
import os

piece_path = "../chess/chess_pieces/white-queen.png"
img_path=os.path.abspath(piece_path)


import wx

class TestFrame(wx.Frame):
    def __init__(self, *args, **kwargs):
        wx.Frame.__init__(self, *args, **kwargs)
        self.MaxImageSize = 500
        self.Image = wx.StaticBitmap(self, bitmap=wx.Bitmap(self.MaxImageSize, self.MaxImageSize))
        box = wx.BoxSizer(wx.VERTICAL)
        box.Add(self.Image, 0, wx.ALL, 10)
        self.SetSizer(box)

        Img = wx.Image(img_path, wx.BITMAP_TYPE_ANY)
# scale the image, keeping ratio
        W = Img.GetWidth()
        H = Img.GetHeight()
        print("Actual image size Width",W,"Height",H)
        if W > H:
            NewW = self.MaxImageSize
            NewH = self.MaxImageSize * H / W
        else:
            NewH = self.MaxImageSize
            NewW = self.MaxImageSize * W / H
        NewH = int(NewH)
        NewW = int(NewW)
        print("New image size Width",NewW,"Height",NewH)
        Img = Img.Scale(NewW,NewH,quality=wx.IMAGE_QUALITY_HIGH)
        self.Image.SetBitmap(wx.Bitmap(Img))
        self.Show()

class App(wx.App):
    def OnInit(self):
        frame = TestFrame(None, -1, "wxBitmap Test")
        return True

if __name__ == "__main__":
    app = App()