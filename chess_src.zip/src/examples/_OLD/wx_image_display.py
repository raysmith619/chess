#wx_image_display.py
#start code

import wx, os

class ImageFrame(wx.Frame):
    def __init__(self, parent, id, title, img_path=None):
        super().__init__(parent, id, title, style=wx.DEFAULT_FRAME_STYLE ^ wx.RESIZE_BORDER)

        image = wx.StaticBitmap(self, wx.ID_ANY)
        png = wx.Image(img_path, wx.BITMAP_TYPE_ANY).ConvertToBitmap()
        image.SetBitmap(wx.Bitmap(img_path))

        sizer = wx.BoxSizer()
        sizer.Add(image)
        self.SetSizerAndFit(sizer)

        self.Show(True)

if __name__ == '__main__':
    app = wx.App()
    piece_path = "../../chess_pieces/white_queen.png"
    frame = ImageFrame(None, id=wx.ID_ANY, title="image", img_path=os.path.realpath(piece_path))
    app.MainLoop()
