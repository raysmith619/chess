#wx_rendering_positioning.py

import wx, os

os.chdir(os.path.dirname(__file__))     # set this dir to be working dir
pieces_dir = "../chess_pieces"
piece_file = "white-queen.png"
image_file = os.path.join(pieces_dir, piece_file)

class Frame(wx.Frame):
    def __init__(self, parent, id, title, img_path):
        super().__init__(parent, id, title, style=wx.DEFAULT_FRAME_STYLE ^ wx.RESIZE_BORDER)

        image = wx.StaticBitmap(self, wx.ID_ANY)
        png = wx.Image(img_path, wx.BITMAP_TYPE_ANY).ConvertToBitmap()
        image.SetBitmap(wx.Bitmap(img_path))

        sizer = wx.BoxSizer()
        sizer.Add(image)
        self.SetSizerAndFit(sizer)

        self.Show(True)
        
app = wx.App()
frame = Frame(None, wx.ID_ANY, "Image", image_file)
app.MainLoop()