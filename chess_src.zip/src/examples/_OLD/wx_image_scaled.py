#wx_image_scaled.py  07Apr2025  from net
import os
import wx
os.chdir(os.path.dirname(__file__))     # set this dir to be working dir
pieces_dir = "../chess_pieces"
piece_file ="white-queen.png"
image_file = os.path.join(pieces_dir, piece_file)
class TestFrame(wx.Frame):
    def __init__(self, *args, **kwargs):
        wx.Frame.__init__(self, *args, **kwargs)
        self.MaxImageSize = 500
        self.Image = wx.StaticBitmap(self, bitmap=wx.Bitmap(self.MaxImageSize, self.MaxImageSize))
        box = wx.BoxSizer(wx.VERTICAL)
        box.Add(self.Image, 0, wx.ALL, 10)
        self.SetSizer(box)

        png = wx.PNGHandler()
        Img = wx.Image(image_file, wx.BITMAP_TYPE_PNG)
# scale the image, keeping ratio
        W = Img.GetWidth()
        H = Img.GetHeight()
        print("Actual image size Width",W,"Height",H)
        if W > H:
            NewW = self.MaxImageSize
            NewH = self.MaxImageSize * H / W
        else:
            NewH = self.MaxImageSize
            NewW = self.MaxImageSize * W / H
        print("New image size Width",NewW,"Height",NewH)
        Img = Img.Scale(NewW,NewH,quality=wx.IMAGE_QUALITY_HIGH)
        self.Image.SetBitmap(wx.Bitmap(Img))
        self.Show()

class App(wx.App):
    def OnInit(self):
        frame = TestFrame(None, -1, "wxBitmap Test")
        return True

if __name__ == "__main__":
    app = App()