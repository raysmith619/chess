#wx_image_png_file.py
# loaging PNG image file
import os
import wx

piece_path = "../chess/chess_pieces/white-queen.png"
img_path=os.path.abspath(piece_path)
app = wx.App()
png = wx.PNGHandler()
print(f"Image file: {img_path}")
try:
    with open(img_path) as f:        
        image = wx.Image()
        if not png.LoadFile(image,wx.StreamBase(f),verbose=True):
            raise Exception(f"load failure for {img_path}")

except IOError:
    print("Image file %s not found" % img_path)
    raise SystemExit
 
 
# create a window/frame, no parent, -1 is default ID
# increase the size of the frame for larger images
frame1 = wx.Frame(None, -1, "An image on a panel", size = (400, 300))
# call the derived class
#Panel1(frame1,-1)
frame1.Show(1)
app.MainLoop()
