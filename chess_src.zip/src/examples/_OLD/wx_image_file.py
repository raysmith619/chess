#wx_image_file.py
# from: https://discuss.wxpython.org/t/rendering-displaying-an-image-in-on-a-wx-frame/29230
# actually you can load .jpg  .png  .bmp  or .gif files
import os
import wx

piece_path = "../../chess_pieces/white_queen.png"
img_path=os.path.realpath(piece_path)
app = wx.PySimpleApp()
try:
    jpg1 = wx.Image(img_path, wx.BITMAP_TYPE_ANY).ConvertToBitmap()
    # bitmap upper left corner is in the position tuple (x, y) = (5, 5)
    wx.StaticBitmap(None, -1, jpg1, (10 + jpg1.GetWidth(), 5), (jpg1.GetWidth(), jpg1.GetHeight()))
except IOError:
    print("Image file %s not found" % piece_path)
    raise SystemExit
 
 
# create a window/frame, no parent, -1 is default ID
# increase the size of the frame for larger images
frame1 = wx.Frame(None, -1, "An image on a panel", size = (400, 300))
# call the derived class
#Panel1(frame1,-1)
frame1.Show(1)
app.MainLoop()
