# wx_drawing_png.py 

import wx
import os
os.chdir(os.path.dirname(__file__))     # set this dir to be working dir
pieces_dir = "../../chess_pieces"
piece_file = "white-queen.png"
piece_path = os.path.abspath(os.path.join(pieces_dir,piece_file))
print(f"{piece_path =}")
class Mywin(wx.Frame):

   def __init__(self, parent, title):
        super(Mywin, self).__init__(parent, title = title,size = (500,300))
        wx.InitAllImageHandlers()
        wx.Image.AddHandler(wx.PNGHandler())
        bmp_Img=wx.Image(piece_path, type=wx.BITMAP_TYPE_PNG)
        frame_size = self.GetSize()
        frame_h = frame_size[0]
        frame_w = frame_size[1]
        final_ImgResized = bmp_Img.Scale(frame_h,frame_w)
        wx.dc = wx.ClientDC(self)
        fgs = wx.FlexGridSizer(2, 1, 10, 10)
        fgs.AddGrowableRow(0)
        self.staticbitmap = wx.StaticBitmap(self)
        fgs.Add(self.staticbitmap, 1, wx.EXPAND)
        self.staticbitmap.SetBitmap(final_ImgResized)
        self.Show(True)

ex = wx.App()
Mywin(None,'Drawing demo')
ex.MainLoop()