# bitmap_numpy.py 
import numpy
import wx

class MyFrame(wx.Frame):
    def __init__(self, parent, id, title):
        super().__init__(parent, id, title, size = (135,655))

        width = 128
        height = 640
        color = (255,255,255)
        array = numpy.zeros((height,width,3),'uint8')
        #array = array[0:320,0:128,0:3]
        array[:,:,] = color
        print(array[10,10,0])
        array[0:128,0:320,0:3] = 0
        print(array[10,10,0])
        image = wx.EmptyImage(width,height)
        image.SetData(array.tostring())
        self.bitmap = image.ConvertToBitmap()
        wx.EVT_PAINT(self, self.OnPaint)

        self.Centre()

    def OnPaint(self, event):
        dc = wx.PaintDC(self)
        dc.DrawBitmap(self.bitmap,3,10)

class MyApp(wx.App):
    def OnInit(self):
        frame = MyFrame(None, -1, '2DS')
        frame.Show(True)
        self.SetTopWindow(frame)
        return True

app = MyApp(0)
app.MainLoop()