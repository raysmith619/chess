#wx_display_image_files.py

import wx

class Frame(wx.Frame):

    def __init__(self, parent):
        super().__init__(parent)

        fgs = wx.FlexGridSizer(2, 1, 10, 10)
        fgs.AddGrowableRow(0)

        self.staticbitmap = wx.StaticBitmap(self)
        fgs.Add(self.staticbitmap, 1, wx.EXPAND)

        browse = wx.Button(self, label='Browse')
        browse.Bind(wx.EVT_BUTTON, self.OnBrowse)
        fgs.Add(browse, flag=wx.LEFT)

        self.SetSizer(fgs)

    def OnBrowse(self, event):
        wildcard = 'PNG files (*.png)|*.png|BMP files (*.bmp)|*.bmp|JPEG files (*.jpg)|*.jpg'
        openFileDialog = wx.FileDialog(self, "Open", "", "", wildcard,
                                       wx.FD_OPEN | wx.FD_FILE_MUST_EXIST)
        openFileDialog.ShowModal()
        url = openFileDialog.GetPath()
        self.staticbitmap.SetBitmap(wx.Bitmap(url))
        event.Skip()

app = wx.App()
frame = Frame(None)
frame.Show()
app.MainLoop()