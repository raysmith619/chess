# wx_png_in_frame.py

import os
import wx
os.chdir(os.path.dirname(__file__))     # set this dir to be working dir
pieces_dir = "../../chess_pieces"
piece_file = "white-queen.png"
piece_path = os.path.abspath(os.path.join(pieces_dir,piece_file))
print(f"{piece_path =}")

class MyFrame(wx.Frame):
    def __init__(self, parent, title, image_path):
        super().__init__(parent, title=title, size=(300, 200))

        # Load the image
        try:
            img = wx.Image(image_path, wx.BITMAP_TYPE_ANY)
            # Convert to bitmap
            bitmap = wx.Bitmap(img)

        except Exception as e:
            print(f"Error loading image: {e}")
            return

        # Create a StaticBitmap control to display the bitmap
        wx.StaticBitmap(self, wx.ID_ANY, bitmap)

        self.Centre()
        self.Show(True)

if __name__ == '__main__':
    app = wx.App(False)
    frame = MyFrame(None, "Bitmap Example", piece_path) 
    app.MainLoop()