#chess_move_parts.py
        
    def decode_if_capture(self, spec, to_move=None):
        """ Check for and process capture
        Examples exd,exd5, Bxe5, Rdxf8, R1xa3, Qh4xe1
        :spec: move specificaiont
        :to_move: whose move
                default: use to_move self or self.board.to_move
        :returns: True if a capture
                if capture, setup move settings
        """
        # with x or : explicit capture
        expl_capture = False
        impl_piece_capture = False
        impl_pawn_capture = False
        if match_expl_capture := re.match(r'^(.*)([x:])(.*)$', spec):
            expl_capture = True
        elif (match_impl_piece_capture :=
                    re.match(r'([KQRBN])(.*)([a-zA-Z][1-8])$', spec)):
            impl_piece_capture = True
        elif (match_impl_pawn_capture :=
                    re.match(r'(([a-z])(.*))$', spec)):
            impl_pawn_capture = True
        else:
            return False
        
        if expl_capture:     
            # Examples:
            # e4:d5, e:d, e:d5 q:a5, Qh4xe1
            # B:a1
            start_str,self.capture_ind,dest_str = match_expl_capture.groups()
            orig_piece,piece_choice = self.get_start_piece(start_str)
            self.dest_sq = self.get_dest_sq(dest_str,
                                            orig_piece=orig_piece)             
            self.orig_sq = self.get_orig_sq(piece=orig_piece,
                                       piece_choice=piece_choice,
                                       dest_sq=self.dest_sq)
                        
    def decode(self, spec,  to_move=None):
        """ Decode notation into:
        in chess notation e.g. e4, e5, Nf3, Nc3, Ncf3, Qh4e1
        :to_move: side making move
                default: not previous move's
                        first: white
        :setups: self.err error text or None, also returned by decode
                self.piece to piece notation e.g. p or P
                self.orig_sq: beginning square e.g. e2
                self.dest_sq: destination square
                self.capt_sq: capture square or None if no capture
                self.dest_sq_mod: alternative to orig_sq contents
                                for say promotions
                            default: destination sq
                                gets piece from self.orig_sq
                self.update: update to_move after move
                self.to_move: Whose move white/black
                    default: use board.to_move
        :returns: None if successful, else err_msg text 
        """
        # Change if/when appropriate
        self.err = None         # Error msg, None == no error
        self.spec = spec        # move specification
        self.is_capture = False # True == capture made
        self.capt_piece = None  # captured piece (on dest_sq)
        self.to_move = None     # to move "white" / "black"
        self.piece = None       # piece e.g, K == white king
        self.orig_sq = None     # move's original square
        self.dest_sq = None     # move's destination square
        self.dest_sq_mod = None # modified dest_sq piece
        self.update = True  # update to_move after successful move
        self.is_castle_king_side = False  # castle kingside
        self.is_castle_queen_side = False # castle queenside
        # piece/square selection results
        self.dest_from_file = None  # dest abrv e.g., e:f
        self.orig_from_file = None  # orig abrv g:h
         
        
        if to_move is None:
            to_move = self.to_move
            if to_move is None:
                to_move = self.board.to_move
        self.spec = spec        
        if spec in ["O-O", "O-O-O"]:
            return self.decode_castle(spec=spec, to_move=to_move)
        
        # check for d:e TBD
        # Check if capture
        if self.decode_if_capture(spec, to_move=to_move):
           return self.err  # decoded - return result
        
        # Pick off destination <file><rank> from tail end
        #   with capture : or x
        if (match_dest_pos := re.match(r'^(.*)([x:])([a-z])(\d+)$', spec)):
            self.is_capture = True
            move_start,capture_str,dest_pos_file, dest_pos_rank = match_dest_pos.groups()        
            self.capt_piece = self.get_piece(dest_pos_file+dest_pos_rank)
        elif (match_dest_pos := re.match(r'^(.*)([a-z])(\d+)$', spec)):
            move_start,dest_pos_file, dest_pos_rank = match_dest_pos.groups()        

        if move_start == '':    # No piece == pawn
            piece = "p" if self.board.to_move == "black" else "P"
            piece_choice = ""
        else:
            # Allow for extended pieces not in kqrbnp,KQRBNP
            if not (match_move_start := re.match(r'([A-Z])(\S*)$', move_start)):
                if not (match_move_pawn_start :=
                        re.match(r'([a-h])(\S*)$', move_start)):
                    self.err = f"Unrecognize move piece: {move_start}"
                    return self.err
                
                orig_file, piece_choice = match_move_pawn_start.groups()
                dest_file_no,dest_rank_no = self.sq_to_file_rank(
                    sq=self.dest_sq,to_int=True)
                vert_sq = self.rel_sq(self.dest_sq, rel_rank=-1)
                vert_file_no,vert_rank_no = self.sq_to_file_rank(
                    vert_sq, to_int=True)
                self.orig_sq = self.file_rank_to_sq(
                    file=vert_file_no, rank=vert_rank_no)
            else:
                piece,piece_choice = match_move_start.groups()
                if self.get_to_move() == 'black':
                    piece = piece.lower()
        self.piece = piece
        self.piece_choice = piece_choice
        self.dest_sq = dest_pos_file+dest_pos_rank
        self.orig_sq = self.get_orig_sq(piece=self.piece,
                                    piece_choice=self.piece_choice,
                                    dest_sq=self.dest_sq)
        SlTrace.lg(f"spec: {self.spec} to_move:{to_move}"
                    f"piece:{self.piece}",
                    "chess_moves")

        if self.orig_sq is None:
            self.err = f"Can't find orig_sq, given {self.spec}"
            return self.err     # Return error msg string
            
        # Pick off destination <file> from tail end e.g. exf
        elif (match_dest_pos := re.match(r'^(.*)[x:]([a-z])$', spec)):
            move_start,dest_pos_file = match_dest_pos.groups()        
            if move_start == '':    # No piece == pawn
                piece = "p" if self.board.to_move == "black" else "P"
                piece_choice = ""
            else:
                # Allow for extended pieces not in kqrbnp,KQRBNP
                if not (match_move_start := re.match(r'([A-Z])(\S*)$', move_start)):
                    self.err = f"Unrecognize move piece: {move_start}"
                    return self.err
            
                piece,piece_choice = match_move_start.groups()
            if self.get_to_move() == 'black':
                piece = piece.lower()
            self.piece = piece
            self.piece_choice = piece_choice
            self.dest_sq = dest_pos_file+dest_pos_rank
            if not self.find_orig_sq():
                return self.err     # Return error msg string
            
    """ From chess_move_notation"""



            
        if (match_dest_pos := re.match(r'^(.*)([x:])([a-z])(\d+)$', spec)):
            self.is_capture = True
            move_start,capture_str,dest_pos_file, dest_pos_rank = match_dest_pos.groups()        
            self.capt_piece = self.get_piece(dest_pos_file+dest_pos_rank)
        elif (match_dest_pos := re.match(r'^(.*)([a-z])(\d+)$', spec)):
            move_start,dest_pos_file, dest_pos_rank = match_dest_pos.groups()        
        
                
                 
        self.spec = spec        
        if spec in ["O-O", "O-O-O"]:
            return self.decode_castle(spec=spec, to_move=to_move)
        
        # check for d:e TBD
        # Check if capture
        if self.decode_if_capture(spec, to_move=to_move):
           return self.err  # decoded - return result

        if move_start == '':    # No piece == pawn
            piece = "p" if self.board.to_move == "black" else "P"
            piece_choice = ""
        else:
            # Allow for extended pieces not in kqrbnp,KQRBNP
            if not (match_move_start := re.match(r'([A-Z])(\S*)$', move_start)):
                if not (match_move_pawn_start :=
                        re.match(r'([a-h])(\S*)$', move_start)):
                    self.err = f"Unrecognize move piece: {move_start}"
                    return self.err
                
                orig_file, piece_choice = match_move_pawn_start.groups()
                dest_file_no,dest_rank_no = self.sq_to_file_rank(
                    sq=self.dest_sq,to_int=True)
                vert_sq = self.rel_sq(self.dest_sq, rel_rank=-1)
                vert_file_no,vert_rank_no = self.sq_to_file_rank(
                    vert_sq, to_int=True)
                self.orig_sq = self.file_rank_to_sq(
                    file=vert_file_no, rank=vert_rank_no)
            else:
                piece,piece_choice = match_move_start.groups()
                if self.get_to_move() == 'black':
                    piece = piece.lower()
        self.piece = piece
        self.piece_choice = piece_choice
        self.dest_sq = dest_pos_file+dest_pos_rank
        self.orig_sq = self.get_orig_sq(piece=self.piece,
                                    piece_choice=self.piece_choice,
                                    dest_sq=self.dest_sq)
        SlTrace.lg(f"spec: {self.spec} to_move:{to_move}"
                    f"piece:{self.piece}",
                    "chess_moves")

        if self.orig_sq is None:
            self.err = f"Can't find orig_sq, given {self.spec}"
            return self.err     # Return error msg string
            
        # Pick off destination <file> from tail end e.g. exf
        elif (match_dest_pos := re.match(r'^(.*)[x:]([a-z])$', spec)):
            move_start,dest_pos_file = match_dest_pos.groups()        
            if move_start == '':    # No piece == pawn
                piece = "p" if self.board.to_move == "black" else "P"
                piece_choice = ""
            else:
                # Allow for extended pieces not in kqrbnp,KQRBNP
                if not (match_move_start := re.match(r'([A-Z])(\S*)$', move_start)):
                    self.err = f"Unrecognize move piece: {move_start}"
                    return self.err
            
                piece,piece_choice = match_move_start.groups()
            if self.get_to_move() == 'black':
                piece = piece.lower()
            self.piece = piece
            self.piece_choice = piece_choice
            self.dest_sq = dest_pos_file+dest_pos_rank
            if not self.find_orig_sq():
                return self.err     # Return error msg string

        
    def decode_if_capture(self, spec, to_move=None):
        """ Check for and process capture
        Examples exd,exd5, Bxe5, Rdxf8, R1xa3, Qh4xe1
        :spec: move specificaiont
        :to_move: whose move
                default: use to_move self or self.board.to_move
        :returns: True if a capture
                if capture, setup move settings
        """
        # with x or : explicit capture
        expl_capture = False
        impl_piece_capture = False
        impl_pawn_capture = False
        if match_expl_capture := re.match(r'^(.*)([x:])(.*)$', spec):
            expl_capture = True
        elif (match_impl_piece_capture :=
                    re.match(r'([KQRBN])(.*)([a-zA-Z][1-8])$', spec)):
            impl_piece_capture = True
        elif (match_impl_pawn_capture :=
                    re.match(r'(([a-z])(.*))$', spec)):
            impl_pawn_capture = True
        else:
            return False
        
        if expl_capture:     
            # Examples:
            # e4:d5, e:d, e:d5 q:a5, Qh4xe1
            # B:a1
            start_str,self.capture_ind,dest_str = match_expl_capture.groups()
            orig_piece,piece_choice = self.get_start_piece(start_str)
            self.dest_sq = self.get_dest_sq(dest_str,
                                            orig_piece=orig_piece)             
            self.orig_sq = self.get_orig_sq(piece=orig_piece,
                                       piece_choice=piece_choice,
                                       dest_sq=self.dest_sq)

    def is_pawn(self, piece):
        """ Check if a pawn
        :piece: piece notation
        """
        return True if (piece == "P" or piece == "p") else False

    def is_some_piece_choice(self):
        """ Check if a non-empty piece disambiguation
        """
        if (self.piece_choice is not None
            and self.piece_choice != ""):
            return True
        
        return False

