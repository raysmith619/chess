
    def show_window(self):
        windows_d = {}     # windows by title
        windows_options = []
        for wt in ChessboardDisplay.window_list:
            win_cbd = wt
            win_title = win_cbd.title
            windows_options.append(win_title) 
            windows_d[win_title] = win_cbd
              
        win_variable = tk.StringVar(self.mw)
        win_variable.set(windows_options[0]) # default value

        w = tk.OptionMenu(self.mw, win_variable, *windows_options)
        w.pack()

08Feb2025
           
               
        if self.scan_moves_iter is None:
            if self.scan_games_iter is None:
                if self.scan_files_iter is None:
                    self.scan_files_iter = self.iterate_game_files(self.games_dir)
                    file_path = self.scan_files_iter.__next__()
                    if file_path is None:
                        self.scan_files_iter = None     # next file
                        self.after(cmd=self.scan_do_moves)
                        return
                    
                    self.scan_games_iter = pgn.GameIterator(file_path)
                    game = self.scan_games_iter.next()
                    if game is None:
                        self.scan_games_iter = None # next game
                        self.after(cmd=self.scan_do_moves)
                        return
                    self.scan_moves_iter = self.iterate_game_moves(game)
                    move = self.scan_moves_iter.next()
                    if move is None:
                        self.scan_moves_iter = None
                        self.after(cmd=self.scan_do_moves)  # Next game
                        return
        
        game = self.scan_moves_iter.next()
        if game is None:
            self.scan_moves_iter = None                    
            self.after(cmd=self.scan_do_moves)  # Next game
            return
        
        self.mw.after(0, self.on_cmd, "f")  # update show with new game
                
                        
        if self.scan is None:                
            if self.scan_game is None:
                self.scan_file_iter = 
                
                file_path = self.scan_file_iter.__next__()
                if file_path is not None:
                    self.scan_game_iter = pgn.GameIterator(file_path) 
            self.scan_next_game()
