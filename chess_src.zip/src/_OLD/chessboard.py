#chessboard.py 05Feb2025  crs
import re

"""
Experimentation of manipulation of a chess board
Goals:
    efficient display
    efficient access
"""
from chess_piece_images import ChessPieceImages
from select_trace import SlTrace

class Chessboard:
    def __init__(self,
                 pieces = None,
                 base_board = None,
                 nsqx = 8,
                 nsqy = 8,
                ):
        """ Setup board, optional display
        :pieces: pieces to add
                1. Short hand string :(<piece><square>)* <to move> 
                    where <piece> is [KQRBNPkqrbnp] as in FEN
                    where <square> is Algebraic notaion, e.g. e4
                    where <to move> is w for white, b for black
                    OR
                2. FEN:<FEN string>
                default: No additional pieces added
                    FEN is the abbreviation of Forsyth-Edwards Notation,
                    and it is the standard notation to describe positions
                    of a chess game.
                    
        :base_board: Chess board on which this is based
                default: None - no base
        :nsqx: Number of squares horizontal
                default: 8
        :nsqy: Number of squares vertical
                default: 8
        """
        self.pieces = pieces
        self.base_board = base_board
        self.nsqx = nsqx
        self.nsqy = nsqy
        self.setup_board()

    def setup_board(self):
        """ Set board internals
        especially board for efficient access to board contents
        """        
        piece_string = self.pieces                
        if piece_string is None or piece_string == "":
            return      # No pieces
        
        if piece_string[0] == ":":  # Check for short form
            short_string = piece_string[1:]
            match_pieces = list(re.finditer(r'([KQRBNPkqrbnp]([a-h])([1-8]))', short_string))
            if not match_pieces:                
                SlTrace.lg(f"short_string: {short_string} is not proper syntax")
                raise Exception(f"short_string: '{short_string}' is not proper piece-square syntax")
            last_piece = match_pieces[-1]
            end_pieces = last_piece.end()
            piece_squares = []
            SlTrace.lg(f"match groups:{match_pieces}")
            to_move_str = short_string[end_pieces:]
            SlTrace.lg(f"pieces:{short_string[:end_pieces]} remainding:{to_move_str}")
            for m in match_pieces:
                piece_squares.append(m.group())
            SlTrace.lg(f"match groups:{piece_squares}")
            self.piece_squares = piece_squares
            match_to_move = re.match(r'^\s*([wb])', to_move_str)
            if match_to_move:
                to_move = match_to_move.group(1)
            self.to_move = to_move
            SlTrace.lg(f"to_move:{to_move}")        
        elif piece_string.upper().startswith("FEN:"):
            self.fen_setup(piece_string[4:])
        else:    
            raise Exception("We don't yet handle anything other than short form")
        
    def fen_setup(self, fen_str):
        """ Setup board piece_squares from FEN string
        setup self.piece_squares list of <piece><location> strings
        Initially just first field
        :fen_str:  FEN notation string
        """
        self.piece_squares = []
        fs = fen_str
        rank_n = self.nsqy
        while rank_n > 0 and len(fs) > 0:
            match_row = re.match(f'([^/]+)([/\s]|$)', fs)
            if match_row:
                row_str = match_row.group(1)
                self.fen_setup_row(rank_n, row_str, self.piece_squares)
                match_str = match_row.group()
                fs = fs[len(match_str):]    
            rank_n -= 1      # from top to bottom

    def fen_setup_row(self, rank_n, row_str, piece_squares):
        """ Setup from fen row
        :board_rank_n: rank 1...self.nsqy
        :row_str: row str e.g. 3qkbnr
        :piece_squares: list to which add piece_square e.g., ra8
        :returns: number piece_square added
        """
        board_file_strs = "abcdefgh"
        board_rank_strs = "12345678"
        board_file_no = 1
        n_placed = 0
        for ch in row_str:
            if pmatch := re.match(r'[rnbqkpRNBQKP]', ch):
                piece_pl = (pmatch.group() + board_file_strs[board_file_no-1]
                            + board_rank_strs[rank_n-1])
                piece_squares.append(piece_pl)
                board_file_no += 1
                n_placed += 1
            elif pmatch := re.match(r'[1-8]', ch):
                board_file_no += int(pmatch.group())    # Skip squares
            else:
                err = f"FEN row character:{ch} not recognized in row_str:{row_str}"
                SlTrace.lg(err)
                raise Exception(err)
        return n_placed
            
import tkinter as tk
class ChessboardDisplay:
    def __init__(self,
                 board,
                 sq_size = 80,
                 displayed = True,
                 light_sq = "#fc9",        # tan
                 dark_sq = "#a65",         # brown
                 #light_sq = "#ffffff",      # white
                 #dark_sq = "#769656",       # green
                ):
        self.board = board
        self.sq_size = sq_size
        self.displayed = displayed
        self.light_sq = light_sq
        self.dark_sq = dark_sq

    def setup_board_canvas(self, mw):
        """ Setup board frame, canvas
        :mw: main window
        """
        board = self.board
        border_color = "dark gray"
        border_thickness = self.sq_size//2
        board_frame = tk.Frame(mw, bg="red")
        board_frame.pack(side=tk.TOP, expand=tk.Y, fill=tk.BOTH)
        tbm_frame = tk.Frame(board_frame, bg="green")
        tbm_frame.pack(side=tk.TOP, expand=tk.Y, fill=tk.BOTH)        
        top_border_frame = tk.Frame(tbm_frame, bg=border_color, height=border_thickness)
        top_border_frame.pack(side=tk.TOP, expand=tk.N, fill=tk.BOTH)
        board_squares_frame = tk.Frame(tbm_frame)
        board_squares_frame.pack(side=tk.TOP, expand=tk.Y, fill=tk.BOTH)
        bottom_border_frame = tk.Frame(tbm_frame, bg=border_color, height=border_thickness)
        bottom_border_frame.pack(side=tk.TOP, expand=tk.N, fill=tk.BOTH)
        
        bd_width=self.sq_size*board.nsqx
        bd_height=self.sq_size*board.nsqy + self.sq_size   # fudge ???
        canvas = tk.Canvas(board_squares_frame, width=bd_width, height=bd_height)
        canvas.pack(side=tk.TOP, expand=tk.Y, fill=tk.BOTH)
        self.canvas = canvas
        self.chess_piece_images = ChessPieceImages()

    def display(self, mw=None):
        """ Display board
        """    
        if mw is None:
            mw = tk.Tk()
        self.mw = mw
        self.setup_board_canvas(mw)
        self.setup_chess_pieces()
        squares_bounds = []         # square bounds array [ic][ir]
        board = self.board
        border_size = self.sq_size//2
        x_left = border_size
        y_top = border_size        
        y_bot = y_top + board.nsqy*self.sq_size   # y increases downward
        # Example: canvas.create_rectangle(ul_cx1,ul_cy1, lr_cx2,lr_cy2, ...)
        for ic in range(board.nsqx):     # index col left to right
            sb_col = []
            for ir in range(board.nsqy): # index row bottom to top
                ul_cx1 = x_left + ic*self.sq_size
                ul_cy1 = y_bot - ir*self.sq_size
                lr_cx2 = ul_cx1 + self.sq_size 
                lr_cy2 = ul_cy1 + self.sq_size
                sq_color = self.dark_sq if (ic+ir)%2==0 else self.light_sq
                self.canvas.create_rectangle(ul_cx1, ul_cy1, lr_cx2, lr_cy2, fill=sq_color)
                sq_bounds = (ul_cx1, ul_cy1, lr_cx2, lr_cy2)
                sb_col.append(sq_bounds)    # Add next row to up
                SlTrace.lg(f"{ic} {ir} self.canvas.create_rectangle("
                           f"x1:{ul_cx1},y1:{ul_cy1},x2:{lr_cx2},y2:{lr_cy2}, fill={sq_color})",
                           "build_display")
            squares_bounds.append(sb_col)   # Add next column to right
        self.squares_bounds = squares_bounds
        #
        # Display pieces
        #
        board = self.board
        for ps in board.piece_squares:
            self.display_piece_square(ps)

    def display_piece_square(self, ps):
        """ Display piece in square
        :ps: piece-square e.g. Ke8 is black King in original square e8
        """            
        if match := re.match(r'([KQRBNPkqrbnp])([a-h])([1-8])', ps):
            piece = match.group(1)
            sq_file = match.group(2)
            sq_rank = match.group(3)
            ic = ord(sq_file)-ord('a')
            ir = int(sq_rank)-1
            sq_bounds = self.squares_bounds[ic][ir]
            ul_cx1, ul_cy1, lr_cx2, lr_cy2 = sq_bounds
            c_x = (ul_cx1+lr_cx2)//2
            c_y = (ul_cy1+lr_cy2)//2
            photo = self.piece_images[piece]
            self.canvas.create_image(c_x, c_y, anchor=tk.CENTER, image=photo)

        else:
            err = f"Unrecognized piece-square: {ps}"
            SlTrace.lg(err)
            raise Exception(err)

    def setup_chess_pieces(self):
        """ Setup the piece images, currently size fixed
        """
        self.cpi = ChessPieceImages()
        self.piece_images = self.cpi.get_image_dict()

        
if __name__ == "__main__":
    SlTrace.clearFlags()
    #cb = Chessboard(pieces=':Kc1Qe1kh7 w')
    cb = Chessboard(pieces='FEN:rnbqkbnr/pppppppp/8/8/8/8/PPPPPPPP/RNBQKBNR')
    cbd = ChessboardDisplay(cb)
    cbd.display()
    SlTrace.save_propfile()
    cbd.mw.mainloop()
    