        self.pieces = []        # piece-squares if any
        #self.SetTitle("wxPython Canvas shapes")
        self.Centre()
        self.Show()

        self.SetBackgroundColour(self.background)
        self.squares_bounds = []         # square bounds array [ic][ir]
        border_size = self.sq_size//2
        x_left = border_size    ### - self.sq_size//2
        y_top = border_size     ### - self.sq_size//2        
        y_bot = y_top + self.nsqy*self.sq_size   # y increases downward
        bd_width = int(self.nsqx*self.sq_size+2*border_size)
        bd_height = int(self.nsqy*self.sq_size+2*border_size+2*border_size)
        # Example: canvas.create_rectangle(ul_cx1,ul_cy1, lr_cx2,lr_cy2, ...)
        for ic in range(self.nsqx):     # index col left to right
            sb_col = []
            for ir in range(self.nsqy): # index row bottom to top
                ul_cx1 = int(x_left + ic*self.sq_size)
                ul_cy1 = int(y_bot - (ir+1)*self.sq_size)
                lr_cx2 = int(ul_cx1 + self.sq_size) 
                lr_cy2 = int(ul_cy1 + self.sq_size)
                sq_color = self.dark_sq if (ic+ir)%2==0 else self.light_sq
                
                rect = wx.Rect(wx.Point(ul_cx1, ul_cy1), wx.Point(lr_cx2, lr_cy2))
                self.create_rectangle(ul_cx1,ul_cy1,lr_cx2,lr_cy2, fill=sq_color)

                sq_bounds = (ul_cx1, ul_cy1, lr_cx2, lr_cy2)
                sb_col.append(sq_bounds)    # Add next row to up
                rank_font = wx.Font(wx.FontInfo(12))
                rank_label = str(ir+1)
                ###rank_w,rank_h = dc.GetTextExtent(rank_label)
                rank_w,rank_h = 10,10   #TFD
                rank_label_cx = int(x_left - border_size/2 - rank_w/2)
                rank_label_cy = int((lr_cy2+ul_cy1)//2 -5)
                self.create_text(rank_label_cx, rank_label_cy, text=rank_label, font=rank_font)
                SlTrace.lg(f"{ic} {ir} self.DrawRectangle("
                           f"x1:{ul_cx1},y1:{ul_cy1},x2:{lr_cx2},y2:{lr_cy2}, fill={sq_color})",
                                "build_display")
                file_label_cx = int((ul_cx1+lr_cx2)//2)
                file_label_cy = int(y_bot + border_size/4)
                file_label = chr(ord('a')+ic)
                self.create_text(file_label_cx, file_label_cy, text=file_label, font=rank_font)
            self.squares_bounds.append(sb_col)   # Add next column to right
        piece_squares = self.get_pieces()
        if piece_squares:
            self.display_pieces(piece_squares=piece_squares)
        self.display_items()
